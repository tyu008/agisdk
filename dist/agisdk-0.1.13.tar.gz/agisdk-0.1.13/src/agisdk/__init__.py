def hello_agi(name="World"):
    """Print a friendly greeting for AGI development."""
    message = f"Hello {name}, welcome to AGI SDK!"
    print(message)
    return message

from . import tasks